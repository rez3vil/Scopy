scopy.ScoRepresent package
==========================

Submodules
----------

scopy.ScoRepresent.daylight module
----------------------------------

.. automodule:: scopy.ScoRepresent.daylight
   :members:
   :undoc-members:
   :show-inheritance:

scopy.ScoRepresent.efg module
-----------------------------

.. automodule:: scopy.ScoRepresent.efg
   :members:
   :undoc-members:
   :show-inheritance:

scopy.ScoRepresent.estate module
--------------------------------

.. automodule:: scopy.ScoRepresent.estate
   :members:
   :undoc-members:
   :show-inheritance:

scopy.ScoRepresent.fingerprints module
--------------------------------------

.. automodule:: scopy.ScoRepresent.fingerprints
   :members:
   :undoc-members:
   :show-inheritance:

scopy.ScoRepresent.ghosecrippen module
--------------------------------------

.. automodule:: scopy.ScoRepresent.ghosecrippen
   :members:
   :undoc-members:
   :show-inheritance:

scopy.ScoRepresent.ifg module
-----------------------------

.. automodule:: scopy.ScoRepresent.ifg
   :members:
   :undoc-members:
   :show-inheritance:

scopy.ScoRepresent.maccs module
-------------------------------

.. automodule:: scopy.ScoRepresent.maccs
   :members:
   :undoc-members:
   :show-inheritance:

scopy.ScoRepresent.morgan module
--------------------------------

.. automodule:: scopy.ScoRepresent.morgan
   :members:
   :undoc-members:
   :show-inheritance:

scopy.ScoRepresent.pubchem module
---------------------------------

.. automodule:: scopy.ScoRepresent.pubchem
   :members:
   :undoc-members:
   :show-inheritance:

scopy.ScoRepresent.scaffolds module
-----------------------------------

.. automodule:: scopy.ScoRepresent.scaffolds
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: scopy.ScoRepresent
   :members:
   :undoc-members:
   :show-inheritance:
