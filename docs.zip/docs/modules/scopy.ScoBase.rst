scopy.ScoBase package
=====================

Submodules
----------

scopy.ScoBase.FilterWithSmarts module
-------------------------------------

.. automodule:: scopy.ScoBase.FilterWithSmarts
   :members:
   :undoc-members:
   :show-inheritance:

scopy.ScoBase.SmartProcess module
---------------------------------

.. automodule:: scopy.ScoBase.SmartProcess
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: scopy.ScoBase
   :members:
   :undoc-members:
   :show-inheritance:
