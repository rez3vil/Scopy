scopy package
=============

Subpackages
-----------

.. toctree::

   scopy.ScoBase
   scopy.ScoDruglikeness
   scopy.ScoFH
   scopy.ScoPretreat
   scopy.ScoRepresent
   scopy.ScoTox
   scopy.ScoVisualize

Submodules
----------

scopy.ScoConfig module
----------------------

.. automodule:: scopy.ScoConfig
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: scopy
   :members:
   :undoc-members:
   :show-inheritance:
