scopy.ScoFH package
===================

Submodules
----------

scopy.ScoFH.fh\_filter module
-----------------------------

.. automodule:: scopy.ScoFH.fh_filter
   :members:
   :undoc-members:
   :show-inheritance:

scopy.ScoFH.fh\_filter\_Lib module
----------------------------------

.. automodule:: scopy.ScoFH.fh_filter_Lib
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: scopy.ScoFH
   :members:
   :undoc-members:
   :show-inheritance:
